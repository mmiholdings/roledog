# Hosting Strategy

_Describe Netlify + Fly.io setup._

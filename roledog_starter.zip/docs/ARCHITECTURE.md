# Architecture Diagram

![diagram](diagram.png)
